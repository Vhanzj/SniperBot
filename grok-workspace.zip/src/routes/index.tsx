import { createFileRoute } from "@tanstack/react-router";
import { Console } from "@/components/console/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Console />;
}
