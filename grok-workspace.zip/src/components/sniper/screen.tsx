import { aLabel, currentStage, useApp } from "@/lib/store";
import { cn, formatEth } from "@/lib/utils";

export function SniperScreen() {
  const input = useApp((s) => s.input);
  const setInput = useApp((s) => s.setInput);
  const drop = useApp((s) => s.drop);
  const note = useApp((s) => s.note);
  const error = useApp((s) => s.error);
  const stageId = useApp((s) => s.stageId);
  const setStage = useApp((s) => s.setStage);
  const qty = useApp((s) => s.qty);
  const setQty = useApp((s) => s.setQty);
  const mode = useApp((s) => s.mode);
  const setMode = useApp((s) => s.setMode);
  const phase = useApp((s) => s.phase);
  const findDrop = useApp((s) => s.findDrop);
  const confirm = useApp((s) => s.confirm);
  const stage = currentStage({ drop, stageId });
  const cost = stage ? stage.price * qty : 0;


  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-4 pb-2">
      <label className="flex flex-col gap-2">
        <span className="font-tiny text-[11px] tracking-[0.18em] text-bm-blue uppercase">Drop</span>
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") findDrop();
            }}
            placeholder="OpenSea link or 0x contract"
            aria-label="OpenSea drop link or NFT contract"
            className="min-w-0 flex-1 rounded-[10px] border-2 border-bm-ink/15 bg-bm-white px-3 py-3 text-[13px] outline-none focus:border-bm-blue"
          />
          <button
            type="button"
            className="face-a font-tiny shrink-0 rounded-full px-4 py-3 text-[13px] font-bold"
            onClick={findDrop}
          >
            Find
          </button>
        </div>
        <p className="font-tiny text-[11px] leading-snug text-bm-ink/55">
          Whitelist / FCFS needs the OpenSea link. A raw contract loads public only.
        </p>
      </label>

      {error ? (
        <p className="font-tiny rounded-[10px] border-2 border-bm-sell/30 bg-bm-white px-3 py-2 text-[12px] text-bm-sell">
          {error}
        </p>
      ) : null}

      {drop && stage ? (
        <section className="panel flex flex-col gap-4 p-4" aria-label="Loaded drop">
          <header className="flex items-start justify-between gap-3">
            <div>
              <p className="font-tiny text-[11px] tracking-wide text-bm-blue uppercase">{drop.chain}</p>
              <h2 className="text-2xl font-bold tracking-wide uppercase">{drop.name}</h2>
              <p className="font-tiny mt-1 text-[11px] break-all text-bm-ink/55">{drop.contract}</p>
            </div>
            <StatusPip phase={phase} />
          </header>
          {note ? <p className="font-tiny text-[12px] leading-snug text-bm-ink/70">{note}</p> : null}

          {drop.stages.length > 1 ? (
            <div className="grid grid-cols-2 gap-2" role="listbox" aria-label="Mint stage">
              {drop.stages.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  role="option"
                  aria-selected={s.id === stageId}
                  className={cn(
                    "rounded-[10px] border-2 px-3 py-3 text-left",
                    s.id === stageId ? "border-bm-blue bg-bm-soft" : "border-bm-ink/10 bg-bm-white",
                  )}
                  onClick={() => setStage(s.id)}
                >
                  <span className="block text-sm font-bold">{s.name}</span>
                  <span className="font-tiny text-[11px] text-bm-ink/65">
                    {s.price === 0 ? "Free" : `${formatEth(s.price)} ETH`} · {s.limit}/wallet
                  </span>
                </button>
              ))}
            </div>
          ) : (
            <p className="font-tiny text-[12px]">
              {stage.name} · {stage.price === 0 ? "Free" : `${formatEth(stage.price)} ETH`} · {stage.limit}/wallet
            </p>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="font-tiny text-[11px] tracking-wide uppercase">Mint</span>
              <button type="button" className="face-b size-11 rounded-full text-lg" onClick={() => setQty(qty - 1)} aria-label="Fewer">
                −
              </button>
              <span className="tabular w-6 text-center text-lg font-bold">{qty}</span>
              <button type="button" className="face-b size-11 rounded-full text-lg" onClick={() => setQty(qty + 1)} aria-label="More">
                +
              </button>
            </div>
            <div className="flex rounded-full border-2 border-bm-ink/10 bg-bm-white p-1">
              <button
                type="button"
                className={cn("font-tiny rounded-full px-3 py-2 text-[11px]", mode === "manual" && "bg-bm-soft text-bm-deep")}
                onClick={() => setMode("manual")}
              >
                Confirm myself
              </button>
              <button
                type="button"
                className={cn("font-tiny rounded-full px-3 py-2 text-[11px]", mode === "auto" && "bg-bm-soft text-bm-deep")}
                onClick={() => setMode("auto")}
              >
                Automatic
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3 border-t-2 border-bm-ink/10 pt-3">
            <p className="font-tiny text-[12px] text-bm-ink/70">
              Pay {cost === 0 ? "free" : `${formatEth(cost)} ETH`}
              {mode === "auto" ? " · auto-fires, 10 tries" : " · you fire each try"}
            </p>
            <button
              type="button"
              className="face-a font-tiny rounded-full px-5 py-3 text-[13px] font-bold"
              onClick={confirm}
            >
              A · {aLabel(phase, mode)}
            </button>
          </div>
        </section>
      ) : (
        <section className="panel flex flex-col gap-2 p-5">
          <p className="font-tiny text-[11px] tracking-wide text-bm-blue uppercase">Awaiting drop</p>
          <h2 className="text-xl font-bold tracking-wide">Paste a link. Arm the watch.</h2>
          <p className="text-pretty text-[15px] leading-relaxed text-bm-ink/75">
            Preview sniper — no keys, no broadcast. A live bot can spend gas on failed tries. An NFT is not
            guaranteed.
          </p>
        </section>
      )}
    </div>
  );
}

function StatusPip({ phase }: { phase: string }) {
  const label =
    phase === "watching"
      ? "Watching"
      : phase === "minting"
        ? "Minting"
        : phase === "done"
          ? "Done"
          : phase === "fail"
            ? "Stopped"
            : "Ready";
  return (
    <span className="font-tiny inline-flex items-center gap-2 rounded-full border-2 border-bm-ink/10 bg-bm-white px-3 py-1 text-[11px] uppercase">
      <span
        className={cn(
          "size-2 rounded-full",
          phase === "done" && "bg-bm-hold",
          phase === "fail" && "bg-bm-sell",
          (phase === "watching" || phase === "minting") && "bg-bm-blue",
          phase === "ready" && "bg-bm-wait",
        )}
      />
      {label}
    </span>
  );
}
