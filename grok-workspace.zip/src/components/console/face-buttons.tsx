import { aLabel, useApp } from "@/lib/store";

export function FaceButtons() {
  const confirm = useApp((s) => s.confirm);
  const back = useApp((s) => s.back);
  const phase = useApp((s) => s.phase);
  const mode = useApp((s) => s.mode);

  return (
    <div className="flex items-center gap-3">
      <button
        type="button"
        aria-label="Back"
        className="face-b grid size-14 place-items-center rounded-full font-tiny text-[22px] font-bold sm:size-16"
        onClick={back}
      >
        B
      </button>
      <button
        type="button"
        aria-label={aLabel(phase, mode)}
        className="face-a grid size-16 place-items-center rounded-full font-tiny text-[24px] font-bold sm:size-[72px]"
        onClick={confirm}
      >
        A
      </button>
    </div>
  );
}
