import { useApp } from "@/lib/store";

const SRC = {
  open: "/maid-open.png",
  love: "/maid-love.png",
  unamused: "/maid-unamused.png",
} as const;

export function Orb() {
  const expression = useApp((s) => s.expression);
  const pet = useApp((s) => s.pet);

  return (
    <button
      type="button"
      aria-label="Pet the Maid"
      onClick={pet}
      className="glass-orb relative isolate size-12 shrink-0 overflow-hidden rounded-full sm:size-14"
    >
      <span className="pointer-events-none absolute inset-[6%] rounded-full border-2 border-bm-blue/30" />
      <img
        src={SRC[expression]}
        alt=""
        draggable={false}
        className="relative z-[1] h-full w-full object-contain object-bottom select-none"
      />
    </button>
  );
}
