import { useApp } from "@/lib/store";
import { shortAddr } from "@/lib/utils";
import { blip } from "@/lib/sound";

export function WalletButton() {
  const wallet = useApp((s) => s.wallet);
  const pickerOpen = useApp((s) => s.pickerOpen);
  const setPicker = useApp((s) => s.setPicker);
  const connect = useApp((s) => s.connect);
  const disconnect = useApp((s) => s.disconnect);

  const label = !wallet.connected
    ? "CONNECT WALLET"
    : wallet.address
      ? shortAddr(wallet.address)
      : "CONNECTED";

  return (
    <div className="relative">
      <button
        type="button"
        className="wallet-pill font-tiny flex max-w-[168px] min-w-[132px] items-center gap-2 rounded-full py-1 pr-3 pl-1 text-[12px] text-bm-white"
        onClick={() => {
          blip("move");
          setPicker(!pickerOpen);
        }}
      >
        <span className="relative grid size-8 place-items-center overflow-hidden rounded-full border-2 border-bm-white bg-bm-deep">
          <img src="/maid-open.png" alt="" className="h-full w-full object-cover" />
          <span
            className={`absolute -right-0.5 -bottom-0.5 size-2.5 rounded-full border-2 border-bm-deep ${
              wallet.connected ? "bg-bm-hold" : "bg-bm-hinge"
            }`}
          />
        </span>
        <span className="truncate font-medium tracking-wide">{label}</span>
      </button>

      {pickerOpen ? (
        <div
          role="dialog"
          aria-label="Choose wallet"
          className="panel absolute top-[calc(100%+8px)] right-0 z-50 grid min-w-[220px] gap-2 p-3 text-left text-[12px] text-bm-ink"
        >
          <p className="font-tiny font-bold tracking-wide">Choose wallet</p>
          <p className="font-tiny m-0 leading-snug text-bm-ink/70">
            Optional. Holder check is off. Preview chain — nothing is signed.
          </p>
          <button
            type="button"
            className="font-tiny rounded-full border-2 border-bm-blue/30 bg-bm-white px-3 py-2 text-left text-bm-deep"
            onClick={() => connect("holder")}
          >
            Preview holder · 3 Maids
          </button>
          <button
            type="button"
            className="font-tiny rounded-full border-2 border-bm-blue/30 bg-bm-white px-3 py-2 text-left text-bm-deep"
            onClick={() => connect("empty")}
          >
            Empty wallet · still snipes
          </button>
          {wallet.connected ? (
            <button
              type="button"
              className="font-tiny rounded-full border-2 border-bm-ink/15 bg-bm-white px-3 py-2 text-bm-ink"
              onClick={disconnect}
            >
              Disconnect
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
