import { useEffect } from "react";
import { aLabel, useApp } from "@/lib/store";
import { Orb } from "./orb";
import { WalletButton } from "./wallet-button";
import { FaceButtons } from "./face-buttons";
import { SniperScreen } from "@/components/sniper/screen";

export function Console() {
  const confirm = useApp((s) => s.confirm);
  const back = useApp((s) => s.back);
  const pickerOpen = useApp((s) => s.pickerOpen);
  const phase = useApp((s) => s.phase);
  const mode = useApp((s) => s.mode);
  const muted = useApp((s) => s.muted);
  const toggleMute = useApp((s) => s.toggleMute);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable)) {
        if (e.key === "Escape") {
          e.preventDefault();
          back();
        }
        return;
      }
      const k = e.key.toLowerCase();
      if (k === "escape" || k === "b") {
        e.preventDefault();
        back();
        return;
      }
      if (pickerOpen) return;
      if (k === "enter" || e.key === " " || k === "a") {
        e.preventDefault();
        confirm();
      }
      if (k === "m") {
        e.preventDefault();
        toggleMute();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [pickerOpen, back, confirm, toggleMute]);

  return (
    <div className="console-bg relative flex h-svh min-h-svh flex-col overflow-hidden">
      <div className="scanlines pointer-events-none absolute inset-0 z-20" />
      <header className="relative z-30 flex items-center justify-between gap-3 px-4 pt-[max(12px,env(safe-area-inset-top))] pb-2 sm:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <Orb />
          <div className="min-w-0">
            <p className="font-tiny text-[11px] tracking-[0.2em] text-bm-ink/55 uppercase">Open</p>
            <h1 className="truncate text-lg font-bold tracking-[0.08em] uppercase">Maid Sniper</h1>
          </div>
        </div>
        <WalletButton />
      </header>

      <main className="relative z-10 min-h-0 flex-1 overflow-y-auto px-4 pt-2 pb-3 sm:px-6">
        <SniperScreen />
      </main>

      <Tape />

      <footer className="relative z-30 flex items-center justify-between gap-3 px-4 pt-1 pb-[max(12px,env(safe-area-inset-bottom))] sm:px-6">
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="font-tiny rounded-full border-2 border-bm-ink/15 bg-bm-white px-4 py-2 text-[12px] tracking-wide uppercase"
            onClick={toggleMute}
            aria-pressed={muted}
          >
            {muted ? "Muted" : "Mute"}
          </button>
          <a
            href="/maid-sniper.zip"
            download="maid-sniper.zip"
            className="font-tiny rounded-full border-2 border-bm-ink/15 bg-bm-white px-4 py-2 text-[12px] tracking-wide text-bm-ink uppercase"
          >
            Zip
          </a>
        </div>
        <p className="font-tiny hidden text-[11px] text-bm-ink/50 sm:block">A · {aLabel(phase, mode)}</p>
        <FaceButtons />
      </footer>
    </div>
  );
}

function Tape() {
  const phase = useApp((s) => s.phase);
  const attempts = useApp((s) => s.attempts);
  const log = useApp((s) => s.log);
  const line = log[0] ?? "Find a drop to start the tape.";
  const label =
    phase === "watching" || phase === "minting"
      ? `attempts ${attempts}/10`
      : phase === "done"
        ? "minted"
        : phase === "fail"
          ? "stopped"
          : "idle";

  return (
    <section className="dark-panel relative z-20 mx-4 mb-1 rounded-[12px] px-3 py-2 sm:mx-6" aria-live="polite">
      <div className="flex items-center justify-between gap-2">
        <p className="font-tiny text-[11px] tracking-[0.18em] uppercase">Tape</p>
        <p className="font-tiny tabular text-[11px] opacity-70">{label}</p>
      </div>
      <p className="font-tiny mt-1 truncate text-[12px] opacity-90">
        {phase === "done" ? "Lovely. Done. " : null}
        {line}
      </p>
    </section>
  );
}
