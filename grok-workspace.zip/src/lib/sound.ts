let ctx: AudioContext | null = null;
let muted = false;

export function setMuted(next: boolean) {
  muted = next;
}

function audio() {
  if (typeof window === "undefined") return null;
  try {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!ctx) ctx = new AC();
    return ctx;
  } catch {
    return null;
  }
}

export function blip(kind: "move" | "ok" | "back" | "lock") {
  try {
    if (muted) return;
    const ac = audio();
    if (!ac) return;
    void ac.resume();
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = "square";
    const freqs = { move: 620, ok: 880, back: 240, lock: 160 };
    osc.frequency.value = freqs[kind];
    gain.gain.value = 0.04;
    const t = Math.max(ac.currentTime, 0.01);
    gain.gain.setValueAtTime(0.04, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
    osc.connect(gain);
    gain.connect(ac.destination);
    osc.start(t);
    osc.stop(t + 0.1);
  } catch {
    // Preview environments may block Web Audio.
  }
}
