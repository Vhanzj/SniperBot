export type StageKind = "public" | "allowlist";

export type Stage = {
  id: string;
  name: string;
  price: number;
  kind: StageKind;
  limit: number;
};

export type Drop = {
  id: string;
  name: string;
  slugs: string[];
  contract: string;
  chain: string;
  stages: Stage[];
};

export const DEMO_ADDRESS = "0x7a1dB1tMa1d5eEdC0n501eA1pha0000000a1d";

const PUBLIC: Stage = { id: "pub", name: "Public sale", price: 0.001, kind: "public", limit: 5 };
const WL: Stage = { id: "wl", name: "Allowlist / FCFS", price: 0, kind: "allowlist", limit: 2 };

export const DROPS: Drop[] = [
  {
    id: "peasants",
    name: "Peasants",
    slugs: ["peasants-rh", "peasants"],
    contract: "0xaaaa000000000000000000000000000000000001",
    chain: "Robinhood Chain",
    stages: [
      { id: "pub", name: "Public sale", price: 0.0012, kind: "public", limit: 5 },
      { id: "wl", name: "Allowlist / FCFS", price: 0, kind: "allowlist", limit: 2 },
    ],
  },
  {
    id: "hoodlrz",
    name: "Hoodlrz",
    slugs: ["hoodlrz", "hoodlrz-rh"],
    contract: "0xaaaa000000000000000000000000000000000002",
    chain: "Robinhood Chain",
    stages: [
      { id: "pub", name: "Public sale", price: 0.002, kind: "public", limit: 3 },
      { id: "wl", name: "Allowlist / FCFS", price: 0, kind: "allowlist", limit: 1 },
    ],
  },
  {
    id: "fam",
    name: "The Fam",
    slugs: ["the-fam", "thefamrh"],
    contract: "0xaaaa000000000000000000000000000000000003",
    chain: "Robinhood Chain",
    stages: [
      { id: "pub", name: "Public sale", price: 0.0008, kind: "public", limit: 4 },
      { id: "wl", name: "GTD / FCFS", price: 0, kind: "allowlist", limit: 2 },
    ],
  },
  {
    id: "clay",
    name: "Clay Factory",
    slugs: ["clay-factory", "0xclayfactory"],
    contract: "0xaaaa000000000000000000000000000000000004",
    chain: "Robinhood Chain",
    stages: [{ id: "pub", name: "Public sale", price: 0.0044, kind: "public", limit: 3 }],
  },
  {
    id: "beleaf",
    name: "Beleaf on Hood",
    slugs: ["beleaf-on-hood", "beleafonhood"],
    contract: "0xbbbb000000000000000000000000000000000001",
    chain: "Robinhood Chain",
    stages: [
      { id: "pub", name: "Public free", price: 0, kind: "public", limit: 2 },
      { id: "wl", name: "Allowlist", price: 0, kind: "allowlist", limit: 1 },
    ],
  },
  {
    id: "maids",
    name: "Bit Maids",
    slugs: ["bitmaidsofficial", "bit-maids", "bitmaids"],
    contract: "0x95d4000000000000000000000000000000008a41",
    chain: "Robinhood Chain",
    stages: [{ id: "pub", name: "Public sale", price: 0, kind: "public", limit: 5 }],
  },
];

export type ParsedTarget = {
  ok: boolean;
  via: "opensea" | "contract" | "none";
  slug: string;
  raw: string;
};

export function parseTarget(raw: string): ParsedTarget {
  const t = raw.trim();
  if (!t) return { ok: false, via: "none", slug: "", raw: t };
  const sea = t.match(/opensea\.io\/collection\/([a-z0-9-]+)/i);
  if (sea) return { ok: true, via: "opensea", slug: sea[1].toLowerCase(), raw: t };
  if (/^0x[a-fA-F0-9]{40}$/.test(t)) return { ok: true, via: "contract", slug: t.toLowerCase(), raw: t };
  if (/^[a-z0-9-]{3,40}$/i.test(t)) return { ok: true, via: "opensea", slug: t.toLowerCase(), raw: t };
  return { ok: false, via: "none", slug: "", raw: t };
}

function titleFromSlug(slug: string) {
  return slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

export function resolveDrop(raw: string): { drop: Drop; note: string } | { error: string } {
  const parsed = parseTarget(raw);
  if (!parsed.ok) {
    return { error: "Paste an OpenSea collection link or a 0x contract." };
  }

  if (parsed.via === "contract") {
    const hit = DROPS.find((d) => d.contract.toLowerCase() === parsed.slug);
    if (hit) {
      return {
        drop: { ...hit, stages: hit.stages.filter((s) => s.kind === "public") },
        note: "Contract loaded. Public stages only — whitelist needs the OpenSea link.",
      };
    }
    return {
      drop: {
        id: parsed.slug,
        name: `${parsed.slug.slice(0, 6)}…${parsed.slug.slice(-4)}`,
        slugs: [],
        contract: parsed.slug,
        chain: "Robinhood Chain",
        stages: [PUBLIC],
      },
      note: "Unknown contract. Public mint only.",
    };
  }

  const hit = DROPS.find((d) => d.slugs.includes(parsed.slug) || d.id === parsed.slug);
  if (hit) {
    return {
      drop: hit,
      note:
        hit.stages.some((s) => s.kind === "allowlist")
          ? "Both stages loaded. Pick public or whitelist before you arm."
          : "Public stage loaded.",
    };
  }

  return {
    drop: {
      id: parsed.slug,
      name: titleFromSlug(parsed.slug),
      slugs: [parsed.slug],
      contract: "0xunknown00000000000000000000000000000000",
      chain: "Robinhood Chain",
      stages: [PUBLIC, WL],
    },
    note: "Unlisted drop. Sample stages attached so you can still dry-run the sniper.",
  };
}
