import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DEMO_ADDRESS, resolveDrop, type Drop, type Stage } from "./drops";
import { blip, setMuted } from "./sound";

export type Phase = "idle" | "ready" | "watching" | "minting" | "done" | "fail";
export type Mode = "manual" | "auto";

type Wallet = {
  connected: boolean;
  address: string | null;
  maids: number;
  label: string;
};

type State = {
  wallet: Wallet;
  pickerOpen: boolean;
  muted: boolean;
  expression: "open" | "love" | "unamused";
  input: string;
  drop: Drop | null;
  note: string;
  error: string;
  stageId: string;
  qty: number;
  mode: Mode;
  phase: Phase;
  attempts: number;
  log: string[];
  setInput: (v: string) => void;
  setStage: (id: string) => void;
  setQty: (n: number) => void;
  setMode: (m: Mode) => void;
  findDrop: () => void;
  arm: () => void;
  fire: () => void;
  stop: () => void;
  reset: () => void;
  tick: () => void;
  confirm: () => void;
  back: () => void;
  connect: (kind: "holder" | "empty") => void;
  disconnect: () => void;
  setPicker: (open: boolean) => void;
  toggleMute: () => void;
  pet: () => void;
};

const MAX_ATTEMPTS = 10;

let loop: ReturnType<typeof setInterval> | null = null;

function stopLoop() {
  if (loop) {
    clearInterval(loop);
    loop = null;
  }
}

function startLoop() {
  stopLoop();
  loop = setInterval(() => {
    useApp.getState().tick();
  }, 1100);
}

function stamp() {
  return new Date().toLocaleTimeString("en-US", { hour12: false });
}

function pushLog(log: string[], line: string) {
  return [`${stamp()}  ${line}`, ...log].slice(0, 14);
}


export const useApp = create<State>()(
  persist(
    (set, get) => ({
      wallet: { connected: false, address: null, maids: 0, label: "" },
      pickerOpen: false,
      muted: false,
      expression: "open",
      input: "https://opensea.io/collection/peasants-rh",
      drop: null,
      note: "",
      error: "",
      stageId: "pub",
      qty: 1,
      mode: "auto",
      phase: "idle",
      attempts: 0,
      log: [],
      setInput: (v) => set({ input: v, error: "" }),
      setStage: (id) => {
        const drop = get().drop;
        const stage = drop?.stages.find((s) => s.id === id);
        if (!stage) return;
        blip("move");
        set({ stageId: id, qty: Math.min(get().qty, stage.limit) });
      },
      setQty: (n) => {
        const stage = currentStage(get());
        if (!stage) return;
        const next = Math.min(stage.limit, Math.max(1, n));
        if (next === get().qty) return;
        blip("move");
        set({ qty: next });
      },
      setMode: (m) => {
        blip("move");
        set({ mode: m });
      },
      findDrop: () => {
        const res = resolveDrop(get().input);
        if ("error" in res) {
          blip("lock");
          set({ error: res.error, drop: null, phase: "idle", note: "" });
          return;
        }
        blip("ok");
        stopLoop();
        set({
          drop: res.drop,
          note: res.note,
          error: "",
          stageId: res.drop.stages[0]?.id ?? "pub",
          qty: 1,
          phase: "ready",
          attempts: 0,
          log: pushLog([], `found ${res.drop.name}`),
        });
      },
      arm: () => {
        const s = get();
        if (!s.drop || s.phase !== "ready") {
          blip("lock");
          return;
        }
        blip("ok");
        const stage = currentStage(s);
        set({
          phase: "watching",
          attempts: 0,
          log: pushLog(s.log, `armed · ${s.drop.name} · ${stage?.name ?? "stage"} · waiting for open`),
        });
        if (s.mode === "auto") startLoop();
      },
      fire: () => {
        const s = get();
        if (s.phase !== "watching" && s.phase !== "minting") {
          blip("lock");
          return;
        }
        const next = s.attempts + 1;
        const stage = currentStage(s);
        if (next >= 3) {
          blip("ok");
          stopLoop();
          set({
            attempts: next,
            phase: "done",
            expression: "love",
            log: pushLog(s.log, `minted ×${s.qty} · ${stage?.name ?? ""}`),
          });
          return;
        }
        blip("ok");
        set({
          attempts: next,
          phase: s.mode === "manual" ? "watching" : "minting",
          log: pushLog(s.log, `attempt ${next}/${MAX_ATTEMPTS} · ${stage?.name ?? ""}`),
        });
      },
      stop: () => {
        const s = get();
        if (s.phase !== "watching" && s.phase !== "minting") return;
        blip("back");
        stopLoop();
        set({
          phase: "fail",
          expression: "unamused",
          log: pushLog(s.log, "stopped"),
        });
      },
      reset: () => {
        blip("back");
        stopLoop();
        set({
          phase: "idle",
          drop: null,
          note: "",
          error: "",
          attempts: 0,
          log: [],
          expression: "open",
        });
      },
      tick: () => {
        const s = get();
        if (s.phase !== "watching" && s.phase !== "minting") return;
        if (s.mode === "manual" && s.phase === "watching") {
          set({ log: pushLog(s.log, "stage looks open · press A to fire") });
          return;
        }
        if (s.attempts >= MAX_ATTEMPTS) {
          stopLoop();
          set({
            phase: "fail",
            expression: "unamused",
            log: pushLog(s.log, "max attempts · stopped"),
          });
          return;
        }
        get().fire();
      },
      confirm: () => {
        const s = get();
        if (s.pickerOpen) return;
        if (s.phase === "idle") s.findDrop();
        else if (s.phase === "ready") s.arm();
        else if (s.phase === "watching" || s.phase === "minting") {
          if (s.mode === "manual") s.fire();
          else s.stop();
        } else s.reset();
      },
      back: () => {
        const s = get();
        if (s.pickerOpen) {
          set({ pickerOpen: false });
          return;
        }
        if (s.phase === "watching" || s.phase === "minting") {
          s.stop();
          return;
        }
        if (s.phase !== "idle") s.reset();
        else blip("back");
      },
      connect: (kind) => {
        blip("ok");
        if (kind === "holder") {
          set({
            wallet: {
              connected: true,
              address: DEMO_ADDRESS,
              maids: 3,
              label: "Preview holder",
            },
            pickerOpen: false,
          });
        } else {
          set({
            wallet: {
              connected: true,
              address: "0x0000000000000000000000000000000000empty",
              maids: 0,
              label: "Empty wallet",
            },
            pickerOpen: false,
          });
        }
      },
      disconnect: () => {
        blip("back");
        set({
          wallet: { connected: false, address: null, maids: 0, label: "" },
          pickerOpen: false,
        });
      },
      setPicker: (open) => set({ pickerOpen: open }),
      toggleMute: () => {
        const next = !get().muted;
        setMuted(next);
        set({ muted: next });
      },
      pet: () => {
        const order: State["expression"][] = ["open", "love", "unamused"];
        const i = order.indexOf(get().expression);
        set({ expression: order[(i + 1) % order.length] });
        blip("ok");
      },
    }),
    {
      name: "maid-sniper",
      partialize: (s) => ({
        wallet: s.wallet,
        muted: s.muted,
        input: s.input,
        mode: s.mode,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) setMuted(state.muted);
      },
    },
  ),
);

export function currentStage(s: { drop: Drop | null; stageId: string }): Stage | null {
  return s.drop?.stages.find((st) => st.id === s.stageId) ?? s.drop?.stages[0] ?? null;
}

export function aLabel(phase: Phase, mode: Mode) {
  if (phase === "idle") return "Find";
  if (phase === "ready") return "Arm";
  if (phase === "watching" || phase === "minting") return mode === "manual" ? "Fire" : "Stop";
  return "Reset";
}
