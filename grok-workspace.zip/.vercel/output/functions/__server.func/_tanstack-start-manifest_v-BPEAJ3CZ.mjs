//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BPEAJ3CZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DVikI96z.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DVikI96z.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CUq5VOFb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
