import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CYeaYWV7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEMO_ADDRESS = "0x7a1dB1tMa1d5eEdC0n501eA1pha0000000a1d";
var PUBLIC = {
	id: "pub",
	name: "Public sale",
	price: .001,
	kind: "public",
	limit: 5
};
var WL = {
	id: "wl",
	name: "Allowlist / FCFS",
	price: 0,
	kind: "allowlist",
	limit: 2
};
var DROPS = [
	{
		id: "peasants",
		name: "Peasants",
		slugs: ["peasants-rh", "peasants"],
		contract: "0xaaaa000000000000000000000000000000000001",
		chain: "Robinhood Chain",
		stages: [{
			id: "pub",
			name: "Public sale",
			price: .0012,
			kind: "public",
			limit: 5
		}, {
			id: "wl",
			name: "Allowlist / FCFS",
			price: 0,
			kind: "allowlist",
			limit: 2
		}]
	},
	{
		id: "hoodlrz",
		name: "Hoodlrz",
		slugs: ["hoodlrz", "hoodlrz-rh"],
		contract: "0xaaaa000000000000000000000000000000000002",
		chain: "Robinhood Chain",
		stages: [{
			id: "pub",
			name: "Public sale",
			price: .002,
			kind: "public",
			limit: 3
		}, {
			id: "wl",
			name: "Allowlist / FCFS",
			price: 0,
			kind: "allowlist",
			limit: 1
		}]
	},
	{
		id: "fam",
		name: "The Fam",
		slugs: ["the-fam", "thefamrh"],
		contract: "0xaaaa000000000000000000000000000000000003",
		chain: "Robinhood Chain",
		stages: [{
			id: "pub",
			name: "Public sale",
			price: 8e-4,
			kind: "public",
			limit: 4
		}, {
			id: "wl",
			name: "GTD / FCFS",
			price: 0,
			kind: "allowlist",
			limit: 2
		}]
	},
	{
		id: "clay",
		name: "Clay Factory",
		slugs: ["clay-factory", "0xclayfactory"],
		contract: "0xaaaa000000000000000000000000000000000004",
		chain: "Robinhood Chain",
		stages: [{
			id: "pub",
			name: "Public sale",
			price: .0044,
			kind: "public",
			limit: 3
		}]
	},
	{
		id: "beleaf",
		name: "Beleaf on Hood",
		slugs: ["beleaf-on-hood", "beleafonhood"],
		contract: "0xbbbb000000000000000000000000000000000001",
		chain: "Robinhood Chain",
		stages: [{
			id: "pub",
			name: "Public free",
			price: 0,
			kind: "public",
			limit: 2
		}, {
			id: "wl",
			name: "Allowlist",
			price: 0,
			kind: "allowlist",
			limit: 1
		}]
	},
	{
		id: "maids",
		name: "Bit Maids",
		slugs: [
			"bitmaidsofficial",
			"bit-maids",
			"bitmaids"
		],
		contract: "0x95d4000000000000000000000000000000008a41",
		chain: "Robinhood Chain",
		stages: [{
			id: "pub",
			name: "Public sale",
			price: 0,
			kind: "public",
			limit: 5
		}]
	}
];
function parseTarget(raw) {
	const t = raw.trim();
	if (!t) return {
		ok: false,
		via: "none",
		slug: "",
		raw: t
	};
	const sea = t.match(/opensea\.io\/collection\/([a-z0-9-]+)/i);
	if (sea) return {
		ok: true,
		via: "opensea",
		slug: sea[1].toLowerCase(),
		raw: t
	};
	if (/^0x[a-fA-F0-9]{40}$/.test(t)) return {
		ok: true,
		via: "contract",
		slug: t.toLowerCase(),
		raw: t
	};
	if (/^[a-z0-9-]{3,40}$/i.test(t)) return {
		ok: true,
		via: "opensea",
		slug: t.toLowerCase(),
		raw: t
	};
	return {
		ok: false,
		via: "none",
		slug: "",
		raw: t
	};
}
function titleFromSlug(slug) {
	return slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
function resolveDrop(raw) {
	const parsed = parseTarget(raw);
	if (!parsed.ok) return { error: "Paste an OpenSea collection link or a 0x contract." };
	if (parsed.via === "contract") {
		const hit = DROPS.find((d) => d.contract.toLowerCase() === parsed.slug);
		if (hit) return {
			drop: {
				...hit,
				stages: hit.stages.filter((s) => s.kind === "public")
			},
			note: "Contract loaded. Public stages only — whitelist needs the OpenSea link."
		};
		return {
			drop: {
				id: parsed.slug,
				name: `${parsed.slug.slice(0, 6)}…${parsed.slug.slice(-4)}`,
				slugs: [],
				contract: parsed.slug,
				chain: "Robinhood Chain",
				stages: [PUBLIC]
			},
			note: "Unknown contract. Public mint only."
		};
	}
	const hit = DROPS.find((d) => d.slugs.includes(parsed.slug) || d.id === parsed.slug);
	if (hit) return {
		drop: hit,
		note: hit.stages.some((s) => s.kind === "allowlist") ? "Both stages loaded. Pick public or whitelist before you arm." : "Public stage loaded."
	};
	return {
		drop: {
			id: parsed.slug,
			name: titleFromSlug(parsed.slug),
			slugs: [parsed.slug],
			contract: "0xunknown00000000000000000000000000000000",
			chain: "Robinhood Chain",
			stages: [PUBLIC, WL]
		},
		note: "Unlisted drop. Sample stages attached so you can still dry-run the sniper."
	};
}
var ctx = null;
var muted = false;
function setMuted(next) {
	muted = next;
}
function audio() {
	if (typeof window === "undefined") return null;
	try {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!ctx) ctx = new AC();
		return ctx;
	} catch {
		return null;
	}
}
function blip(kind) {
	try {
		if (muted) return;
		const ac = audio();
		if (!ac) return;
		ac.resume();
		const osc = ac.createOscillator();
		const gain = ac.createGain();
		osc.type = "square";
		const freqs = {
			move: 620,
			ok: 880,
			back: 240,
			lock: 160
		};
		osc.frequency.value = freqs[kind];
		gain.gain.value = .04;
		const t = Math.max(ac.currentTime, .01);
		gain.gain.setValueAtTime(.04, t);
		gain.gain.exponentialRampToValueAtTime(1e-4, t + .09);
		osc.connect(gain);
		gain.connect(ac.destination);
		osc.start(t);
		osc.stop(t + .1);
	} catch {}
}
var MAX_ATTEMPTS = 10;
var loop = null;
function stopLoop() {
	if (loop) {
		clearInterval(loop);
		loop = null;
	}
}
function startLoop() {
	stopLoop();
	loop = setInterval(() => {
		useApp.getState().tick();
	}, 1100);
}
function stamp() {
	return (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", { hour12: false });
}
function pushLog(log, line) {
	return [`${stamp()}  ${line}`, ...log].slice(0, 14);
}
var useApp = create()(persist((set, get) => ({
	wallet: {
		connected: false,
		address: null,
		maids: 0,
		label: ""
	},
	pickerOpen: false,
	muted: false,
	expression: "open",
	input: "https://opensea.io/collection/peasants-rh",
	drop: null,
	note: "",
	error: "",
	stageId: "pub",
	qty: 1,
	mode: "auto",
	phase: "idle",
	attempts: 0,
	log: [],
	setInput: (v) => set({
		input: v,
		error: ""
	}),
	setStage: (id) => {
		const stage = get().drop?.stages.find((s) => s.id === id);
		if (!stage) return;
		blip("move");
		set({
			stageId: id,
			qty: Math.min(get().qty, stage.limit)
		});
	},
	setQty: (n) => {
		const stage = currentStage(get());
		if (!stage) return;
		const next = Math.min(stage.limit, Math.max(1, n));
		if (next === get().qty) return;
		blip("move");
		set({ qty: next });
	},
	setMode: (m) => {
		blip("move");
		set({ mode: m });
	},
	findDrop: () => {
		const res = resolveDrop(get().input);
		if ("error" in res) {
			blip("lock");
			set({
				error: res.error,
				drop: null,
				phase: "idle",
				note: ""
			});
			return;
		}
		blip("ok");
		stopLoop();
		set({
			drop: res.drop,
			note: res.note,
			error: "",
			stageId: res.drop.stages[0]?.id ?? "pub",
			qty: 1,
			phase: "ready",
			attempts: 0,
			log: pushLog([], `found ${res.drop.name}`)
		});
	},
	arm: () => {
		const s = get();
		if (!s.drop || s.phase !== "ready") {
			blip("lock");
			return;
		}
		blip("ok");
		const stage = currentStage(s);
		set({
			phase: "watching",
			attempts: 0,
			log: pushLog(s.log, `armed · ${s.drop.name} · ${stage?.name ?? "stage"} · waiting for open`)
		});
		if (s.mode === "auto") startLoop();
	},
	fire: () => {
		const s = get();
		if (s.phase !== "watching" && s.phase !== "minting") {
			blip("lock");
			return;
		}
		const next = s.attempts + 1;
		const stage = currentStage(s);
		if (next >= 3) {
			blip("ok");
			stopLoop();
			set({
				attempts: next,
				phase: "done",
				expression: "love",
				log: pushLog(s.log, `minted ×${s.qty} · ${stage?.name ?? ""}`)
			});
			return;
		}
		blip("ok");
		set({
			attempts: next,
			phase: s.mode === "manual" ? "watching" : "minting",
			log: pushLog(s.log, `attempt ${next}/${MAX_ATTEMPTS} · ${stage?.name ?? ""}`)
		});
	},
	stop: () => {
		const s = get();
		if (s.phase !== "watching" && s.phase !== "minting") return;
		blip("back");
		stopLoop();
		set({
			phase: "fail",
			expression: "unamused",
			log: pushLog(s.log, "stopped")
		});
	},
	reset: () => {
		blip("back");
		stopLoop();
		set({
			phase: "idle",
			drop: null,
			note: "",
			error: "",
			attempts: 0,
			log: [],
			expression: "open"
		});
	},
	tick: () => {
		const s = get();
		if (s.phase !== "watching" && s.phase !== "minting") return;
		if (s.mode === "manual" && s.phase === "watching") {
			set({ log: pushLog(s.log, "stage looks open · press A to fire") });
			return;
		}
		if (s.attempts >= MAX_ATTEMPTS) {
			stopLoop();
			set({
				phase: "fail",
				expression: "unamused",
				log: pushLog(s.log, "max attempts · stopped")
			});
			return;
		}
		get().fire();
	},
	confirm: () => {
		const s = get();
		if (s.pickerOpen) return;
		if (s.phase === "idle") s.findDrop();
		else if (s.phase === "ready") s.arm();
		else if (s.phase === "watching" || s.phase === "minting") {
			if (s.mode === "manual") s.fire();
			else s.stop();
		} else s.reset();
	},
	back: () => {
		const s = get();
		if (s.pickerOpen) {
			set({ pickerOpen: false });
			return;
		}
		if (s.phase === "watching" || s.phase === "minting") {
			s.stop();
			return;
		}
		if (s.phase !== "idle") s.reset();
		else blip("back");
	},
	connect: (kind) => {
		blip("ok");
		if (kind === "holder") set({
			wallet: {
				connected: true,
				address: DEMO_ADDRESS,
				maids: 3,
				label: "Preview holder"
			},
			pickerOpen: false
		});
		else set({
			wallet: {
				connected: true,
				address: "0x0000000000000000000000000000000000empty",
				maids: 0,
				label: "Empty wallet"
			},
			pickerOpen: false
		});
	},
	disconnect: () => {
		blip("back");
		set({
			wallet: {
				connected: false,
				address: null,
				maids: 0,
				label: ""
			},
			pickerOpen: false
		});
	},
	setPicker: (open) => set({ pickerOpen: open }),
	toggleMute: () => {
		const next = !get().muted;
		setMuted(next);
		set({ muted: next });
	},
	pet: () => {
		const order = [
			"open",
			"love",
			"unamused"
		];
		set({ expression: order[(order.indexOf(get().expression) + 1) % order.length] });
		blip("ok");
	}
}), {
	name: "maid-sniper",
	partialize: (s) => ({
		wallet: s.wallet,
		muted: s.muted,
		input: s.input,
		mode: s.mode
	}),
	onRehydrateStorage: () => (state) => {
		if (state) setMuted(state.muted);
	}
}));
function currentStage(s) {
	return s.drop?.stages.find((st) => st.id === s.stageId) ?? s.drop?.stages[0] ?? null;
}
function aLabel(phase, mode) {
	if (phase === "idle") return "Find";
	if (phase === "ready") return "Arm";
	if (phase === "watching" || phase === "minting") return mode === "manual" ? "Fire" : "Stop";
	return "Reset";
}
var SRC = {
	open: "/maid-open.png",
	love: "/maid-love.png",
	unamused: "/maid-unamused.png"
};
function Orb() {
	const expression = useApp((s) => s.expression);
	const pet = useApp((s) => s.pet);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-label": "Pet the Maid",
		onClick: pet,
		className: "glass-orb relative isolate size-12 shrink-0 overflow-hidden rounded-full sm:size-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-[6%] rounded-full border-2 border-bm-blue/30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: SRC[expression],
			alt: "",
			draggable: false,
			className: "relative z-[1] h-full w-full object-contain object-bottom select-none"
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function shortAddr(addr) {
	if (addr.length < 12) return addr;
	return `${addr.slice(0, 6)}…${addr.slice(-4)}`;
}
function formatEth(n) {
	if (n === 0) return "0";
	if (n < 1e-4) return n.toFixed(6);
	if (n < 1) return n.toFixed(4);
	return n.toFixed(3);
}
function WalletButton() {
	const wallet = useApp((s) => s.wallet);
	const pickerOpen = useApp((s) => s.pickerOpen);
	const setPicker = useApp((s) => s.setPicker);
	const connect = useApp((s) => s.connect);
	const disconnect = useApp((s) => s.disconnect);
	const label = !wallet.connected ? "CONNECT WALLET" : wallet.address ? shortAddr(wallet.address) : "CONNECTED";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "wallet-pill font-tiny flex max-w-[168px] min-w-[132px] items-center gap-2 rounded-full py-1 pr-3 pl-1 text-[12px] text-bm-white",
			onClick: () => {
				blip("move");
				setPicker(!pickerOpen);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "relative grid size-8 place-items-center overflow-hidden rounded-full border-2 border-bm-white bg-bm-deep",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/maid-open.png",
					alt: "",
					className: "h-full w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -right-0.5 -bottom-0.5 size-2.5 rounded-full border-2 border-bm-deep ${wallet.connected ? "bg-bm-hold" : "bg-bm-hinge"}` })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate font-medium tracking-wide",
				children: label
			})]
		}), pickerOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-label": "Choose wallet",
			className: "panel absolute top-[calc(100%+8px)] right-0 z-50 grid min-w-[220px] gap-2 p-3 text-left text-[12px] text-bm-ink",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-tiny font-bold tracking-wide",
					children: "Choose wallet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-tiny m-0 leading-snug text-bm-ink/70",
					children: "Optional. Holder check is off. Preview chain — nothing is signed."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "font-tiny rounded-full border-2 border-bm-blue/30 bg-bm-white px-3 py-2 text-left text-bm-deep",
					onClick: () => connect("holder"),
					children: "Preview holder · 3 Maids"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "font-tiny rounded-full border-2 border-bm-blue/30 bg-bm-white px-3 py-2 text-left text-bm-deep",
					onClick: () => connect("empty"),
					children: "Empty wallet · still snipes"
				}),
				wallet.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "font-tiny rounded-full border-2 border-bm-ink/15 bg-bm-white px-3 py-2 text-bm-ink",
					onClick: disconnect,
					children: "Disconnect"
				}) : null
			]
		}) : null]
	});
}
function FaceButtons() {
	const confirm = useApp((s) => s.confirm);
	const back = useApp((s) => s.back);
	const phase = useApp((s) => s.phase);
	const mode = useApp((s) => s.mode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Back",
			className: "face-b grid size-14 place-items-center rounded-full font-tiny text-[22px] font-bold sm:size-16",
			onClick: back,
			children: "B"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": aLabel(phase, mode),
			className: "face-a grid size-16 place-items-center rounded-full font-tiny text-[24px] font-bold sm:size-[72px]",
			onClick: confirm,
			children: "A"
		})]
	});
}
function SniperScreen() {
	const input = useApp((s) => s.input);
	const setInput = useApp((s) => s.setInput);
	const drop = useApp((s) => s.drop);
	const note = useApp((s) => s.note);
	const error = useApp((s) => s.error);
	const stageId = useApp((s) => s.stageId);
	const setStage = useApp((s) => s.setStage);
	const qty = useApp((s) => s.qty);
	const setQty = useApp((s) => s.setQty);
	const mode = useApp((s) => s.mode);
	const setMode = useApp((s) => s.setMode);
	const phase = useApp((s) => s.phase);
	const findDrop = useApp((s) => s.findDrop);
	const confirm = useApp((s) => s.confirm);
	const stage = currentStage({
		drop,
		stageId
	});
	const cost = stage ? stage.price * qty : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-xl flex-col gap-4 pb-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-tiny text-[11px] tracking-[0.18em] text-bm-blue uppercase",
						children: "Drop"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: input,
							onChange: (e) => setInput(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter") findDrop();
							},
							placeholder: "OpenSea link or 0x contract",
							"aria-label": "OpenSea drop link or NFT contract",
							className: "min-w-0 flex-1 rounded-[10px] border-2 border-bm-ink/15 bg-bm-white px-3 py-3 text-[13px] outline-none focus:border-bm-blue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "face-a font-tiny shrink-0 rounded-full px-4 py-3 text-[13px] font-bold",
							onClick: findDrop,
							children: "Find"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-tiny text-[11px] leading-snug text-bm-ink/55",
						children: "Whitelist / FCFS needs the OpenSea link. A raw contract loads public only."
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-tiny rounded-[10px] border-2 border-bm-sell/30 bg-bm-white px-3 py-2 text-[12px] text-bm-sell",
				children: error
			}) : null,
			drop && stage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel flex flex-col gap-4 p-4",
				"aria-label": "Loaded drop",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-tiny text-[11px] tracking-wide text-bm-blue uppercase",
								children: drop.chain
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl font-bold tracking-wide uppercase",
								children: drop.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-tiny mt-1 text-[11px] break-all text-bm-ink/55",
								children: drop.contract
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPip, { phase })]
					}),
					note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-tiny text-[12px] leading-snug text-bm-ink/70",
						children: note
					}) : null,
					drop.stages.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						role: "listbox",
						"aria-label": "Mint stage",
						children: drop.stages.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "option",
							"aria-selected": s.id === stageId,
							className: cn("rounded-[10px] border-2 px-3 py-3 text-left", s.id === stageId ? "border-bm-blue bg-bm-soft" : "border-bm-ink/10 bg-bm-white"),
							onClick: () => setStage(s.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-bold",
								children: s.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-tiny text-[11px] text-bm-ink/65",
								children: [
									s.price === 0 ? "Free" : `${formatEth(s.price)} ETH`,
									" · ",
									s.limit,
									"/wallet"
								]
							})]
						}, s.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-tiny text-[12px]",
						children: [
							stage.name,
							" · ",
							stage.price === 0 ? "Free" : `${formatEth(stage.price)} ETH`,
							" · ",
							stage.limit,
							"/wallet"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-tiny text-[11px] tracking-wide uppercase",
									children: "Mint"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "face-b size-11 rounded-full text-lg",
									onClick: () => setQty(qty - 1),
									"aria-label": "Fewer",
									children: "−"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular w-6 text-center text-lg font-bold",
									children: qty
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "face-b size-11 rounded-full text-lg",
									onClick: () => setQty(qty + 1),
									"aria-label": "More",
									children: "+"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex rounded-full border-2 border-bm-ink/10 bg-bm-white p-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("font-tiny rounded-full px-3 py-2 text-[11px]", mode === "manual" && "bg-bm-soft text-bm-deep"),
								onClick: () => setMode("manual"),
								children: "Confirm myself"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("font-tiny rounded-full px-3 py-2 text-[11px]", mode === "auto" && "bg-bm-soft text-bm-deep"),
								onClick: () => setMode("auto"),
								children: "Automatic"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 border-t-2 border-bm-ink/10 pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-tiny text-[12px] text-bm-ink/70",
							children: [
								"Pay ",
								cost === 0 ? "free" : `${formatEth(cost)} ETH`,
								mode === "auto" ? " · auto-fires, 10 tries" : " · you fire each try"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "face-a font-tiny rounded-full px-5 py-3 text-[13px] font-bold",
							onClick: confirm,
							children: ["A · ", aLabel(phase, mode)]
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel flex flex-col gap-2 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-tiny text-[11px] tracking-wide text-bm-blue uppercase",
						children: "Awaiting drop"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold tracking-wide",
						children: "Paste a link. Arm the watch."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-pretty text-[15px] leading-relaxed text-bm-ink/75",
						children: "Preview sniper — no keys, no broadcast. A live bot can spend gas on failed tries. An NFT is not guaranteed."
					})
				]
			})
		]
	});
}
function StatusPip({ phase }) {
	const label = phase === "watching" ? "Watching" : phase === "minting" ? "Minting" : phase === "done" ? "Done" : phase === "fail" ? "Stopped" : "Ready";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "font-tiny inline-flex items-center gap-2 rounded-full border-2 border-bm-ink/10 bg-bm-white px-3 py-1 text-[11px] uppercase",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", phase === "done" && "bg-bm-hold", phase === "fail" && "bg-bm-sell", (phase === "watching" || phase === "minting") && "bg-bm-blue", phase === "ready" && "bg-bm-wait") }), label]
	});
}
function Console() {
	const confirm = useApp((s) => s.confirm);
	const back = useApp((s) => s.back);
	const pickerOpen = useApp((s) => s.pickerOpen);
	const phase = useApp((s) => s.phase);
	const mode = useApp((s) => s.mode);
	const muted = useApp((s) => s.muted);
	const toggleMute = useApp((s) => s.toggleMute);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const el = e.target;
			if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable)) {
				if (e.key === "Escape") {
					e.preventDefault();
					back();
				}
				return;
			}
			const k = e.key.toLowerCase();
			if (k === "escape" || k === "b") {
				e.preventDefault();
				back();
				return;
			}
			if (pickerOpen) return;
			if (k === "enter" || e.key === " " || k === "a") {
				e.preventDefault();
				confirm();
			}
			if (k === "m") {
				e.preventDefault();
				toggleMute();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		pickerOpen,
		back,
		confirm,
		toggleMute
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "console-bg relative flex h-svh min-h-svh flex-col overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scanlines pointer-events-none absolute inset-0 z-20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-30 flex items-center justify-between gap-3 px-4 pt-[max(12px,env(safe-area-inset-top))] pb-2 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orb, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-tiny text-[11px] tracking-[0.2em] text-bm-ink/55 uppercase",
							children: "Open"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-lg font-bold tracking-[0.08em] uppercase",
							children: "Maid Sniper"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletButton, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "relative z-10 min-h-0 flex-1 overflow-y-auto px-4 pt-2 pb-3 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SniperScreen, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "relative z-30 flex items-center justify-between gap-3 px-4 pt-1 pb-[max(12px,env(safe-area-inset-bottom))] sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "font-tiny rounded-full border-2 border-bm-ink/15 bg-bm-white px-4 py-2 text-[12px] tracking-wide uppercase",
							onClick: toggleMute,
							"aria-pressed": muted,
							children: muted ? "Muted" : "Mute"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/maid-sniper.zip",
							download: "maid-sniper.zip",
							className: "font-tiny rounded-full border-2 border-bm-ink/15 bg-bm-white px-4 py-2 text-[12px] tracking-wide text-bm-ink uppercase",
							children: "Zip"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-tiny hidden text-[11px] text-bm-ink/50 sm:block",
						children: ["A · ", aLabel(phase, mode)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaceButtons, {})
				]
			})
		]
	});
}
function Tape() {
	const phase = useApp((s) => s.phase);
	const attempts = useApp((s) => s.attempts);
	const line = useApp((s) => s.log)[0] ?? "Find a drop to start the tape.";
	const label = phase === "watching" || phase === "minting" ? `attempts ${attempts}/10` : phase === "done" ? "minted" : phase === "fail" ? "stopped" : "idle";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "dark-panel relative z-20 mx-4 mb-1 rounded-[12px] px-3 py-2 sm:mx-6",
		"aria-live": "polite",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-tiny text-[11px] tracking-[0.18em] uppercase",
				children: "Tape"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-tiny tabular text-[11px] opacity-70",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-tiny mt-1 truncate text-[12px] opacity-90",
			children: [phase === "done" ? "Lovely. Done. " : null, line]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Console, {});
}
//#endregion
export { Home as component };
